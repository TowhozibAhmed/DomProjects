
const productData = [
    {
        name: 'Blazer for men',
        price: 200,
        salePrice: 150,
        productPhoto: 'https://4.imimg.com/data4/WT/GN/MY-22995117/mens-blazers-500x500.jpg'
    },
    {
        name: 'Blazer for men',
        price: 200,
        salePrice: 150,
        productPhoto: 'https://4.imimg.com/data4/WT/GN/MY-22995117/mens-blazers-500x500.jpg'
    },
    {
        name: 'Blazer for men',
        price: 200,
        salePrice: 150,
        productPhoto: 'https://4.imimg.com/data4/WT/GN/MY-22995117/mens-blazers-500x500.jpg'
    },
    {
        name: 'Blazer for men',
        price: 200,
        salePrice: 150,
        productPhoto: 'https://4.imimg.com/data4/WT/GN/MY-22995117/mens-blazers-500x500.jpg'
    },
    {
        name: 'Blazer for men',
        price: 200,
        salePrice: 150,
        productPhoto: 'https://4.imimg.com/data4/WT/GN/MY-22995117/mens-blazers-500x500.jpg'
    },
    {
        name: 'Blazer for men',
        price: 200,
        salePrice: 150,
        productPhoto: 'https://4.imimg.com/data4/WT/GN/MY-22995117/mens-blazers-500x500.jpg'
    }
]



// addProduct.addEventListener('click', () => {

//     addProductWrapper.style.display = 'block'

// })

// closeBtn.addEventListener('click', (e) => {
//     e.preventDefault()

//     addProductWrapper.style.display = 'none'

// })


// let productDatas = getData('Product-Datails')

// productForm.addEventListener('submit', (e) => {
//     e.preventDefault()
   


//     if (productName.value == '' || productPrice.value == '' || productSalePrice.value == '' || productImage.value == '') {
//         alert('All Fields are Required')
//     } else {


//         let productName = document.getElementById('productName');
//         let productPrice = document.getElementById('productPrice');
//         let productSalePrice = document.getElementById('productSalePrice');
//         let productImage = document.getElementById('productImage');
    
      


//         let productDataArray = [];
//         if (productDatas) {
//             productDataArray = productDatas;
//         } else {
//             productDataArray = []
//         }
    

//         productDataArray.push({
//             name: productName.value,
//             productPrice: productPrice.value,
//             productSalePrice: productSalePrice.value,
//             productPhoto: productImage.value
//         })

//         sendData('Product-Details', productDataArray)

//         allProducts()



//     }

// })


// allProducts()


// let clearData = document.getElementById('clearProducts');

// clearData.addEventListener('click', () => {

//     localStorage.clear()
//     productLists.innerHTML = '';

// })








